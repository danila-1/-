const Router = require('express')
const route = new Router()
const SessionController = require('../controllers/SessionController')


route.get('/create', SessionController.create);
route.post('/create', SessionController.insert);
route.get('/update/:id', SessionController.edit);
route.post('/update/:id', SessionController.update);
route.get('/delete/:id',SessionController.delete);

module.exports=route