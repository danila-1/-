const Router = require('express')
const route = new Router()
const MainController = require('../controllers/MainController')

route.post('/', MainController.select)
route.get('/', MainController.main)
route.get('/session/buy/:id', MainController.buy);
route.get('/session/unbuy/:id', MainController.unbuy);
module.exports=route