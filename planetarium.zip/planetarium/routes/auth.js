const Router = require('express');
const AuthController = require("../controllers/AuthController");
const route = new Router();

route.get('/auth', AuthController.auth)
route.post('/auth', AuthController.login)
route.get('/reg', AuthController.reg)
route.post('/registration', AuthController.registration)
route.get('/logout', AuthController.logout)

module.exports = route