const Router = require('express');
const UserController = require("../controllers/UserController");
const route = new Router();

route.get('/', UserController.all)
route.get('/delete/:id', UserController.delete)
route.get('/create', UserController.create)
route.post('/create', UserController.insert)
route.get('/update/:id', UserController.edit)
route.post('/update/:id', UserController.update)

module.exports = route