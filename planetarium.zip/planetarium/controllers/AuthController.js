const AuthService = require("../services/AuthService.js");
const flash = require('connect-flash');
class AuthController {

    async auth(req, res) {
        if(req.session.auth && req.session.auth.id) 
        {
            res.redirect('/');
        }

        res.render('auth/auth', {message: req.flash('message')});
    }

    async reg(req, res) {
        if(req.session.auth && req.session.auth.id)
        {
            res.redirect('/');
        }  
        res.render('auth/reg', {message: req.flash('message')});
        
    }

    async login(req, res) {

        const user = await AuthService.check(req.body.login, req.body.password)
        console.log('Логин: ' + req.body.login + ' Пароль ' + req.body.password);
        if(user.length === 1){
            if (req.session.views) {
                req.session.views++;
                req.session.auth = user[0];

            } else {
                req.session.views = 1;
                req.session.auth = user[0];
            }
            res.redirect('/');
        } 
        
        else{
            req.flash('message', 'Неверный логин или пароль');
            res.redirect('/auth/auth');
        }
    }

    async registration(req, res) {
        const check = await AuthService.checkLogin(req.body.login) //Отдельная проверка логина
        if(check.length===0){            
            if(req.body.password.length > 5 ){
                await AuthService.registration(req.body)
                const user = await AuthService.check(req.body.login, req.body.password)
                if (req.session.views) {
                req.session.views++;
                req.session.auth = user[0];
            } else {
                req.session.views = 1;
                req.session.auth = user[0];
            }
            res.redirect('/');
            }
            else
            {
                req.flash('message', 'Пароль должен составлять не менее 6 символов') 
                res.redirect('/auth/reg');  
            }
            
        } else{
            req.flash('message', 'Пользователь уже существует');
            res.redirect('/auth/reg');
        }
    }

    async logout(req,res){
        req.session.views = null
        req.session.auth = {}
        res.redirect('/') 
    }

}

module.exports = new AuthController()