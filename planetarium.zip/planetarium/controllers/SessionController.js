const SessionService = require('../services/SessionService');
const flash = require('connect-flash');

class SessionController {

    async create(req, res){
        if(!req.session.auth.id){
            res.redirect('/')
        }
        res.render('session/create');
    }

    async insert(req, res){
        if(!req.session.auth.id){
            res.redirect('/')
        }
        await SessionService.create(req.body);
        res.redirect('/');
    }

    async delete(req, res){
        
        if(!req.session.auth.id){
            res.redirect('/')
        }
        const check = SessionService.check(req.params.id)
        if(check.lenght > 0){
            req.status(400).send({
                message: 'На данный сеанс имеется запись'
            })
        }
        else
        {
            await SessionService.delete(req.params.id)
            res.redirect('/')
        }
    
    }

    async edit(req, res){
        if(!req.session.auth.id){
            res.redirect('/')
        }
        const data = await SessionService.one(req.params.id);
        res.render('session/update',{
            data: data[0]
        })
    }

    async update (req, res){
        if(!req.session.auth.id){
            res.redirect('/')
        }
        await SessionService.update(req.body, req.params.id);
        res.redirect('/');
    }

}

module.exports = new SessionController();