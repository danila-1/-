const AuthService = require('../services/AuthService');
const UserService = require('../services/UserService');

class UserController{


    async all(req,res){

        const users = await UserService.all();
        res.render('users', {data: users});
        
    }

    async create(req, res){

        res.render('users/create', {message: req.flash('message')});
    }


    async insert(req, res){
        const check = await AuthService.checkLogin(req.body.login) //Отдельная проверка логина
        if(check.length===0){            
            if(req.body.password.length > 5 ){
                await UserService.registration(req.body)
                const user = await AuthService.check(req.body.login, req.body.password)
                if (req.session.views) {
                req.session.views++;
                req.session.auth = user[0];
            } else {
                req.session.views = 1;
                req.session.auth = user[0];
            }
            res.redirect('/users');
            }
            else
            {
                req.flash('message', 'Пароль должен составлять не менее 6 символов') 
                res.redirect('/users/create');  
            }
            
        } else{
            req.flash('message', 'Пользователь уже существует');
            res.redirect('/user/create');
        }
    }

    async edit(req, res){


        const user = await UserService.one(req.params.id);
        console.log('хихихихих')
        res.render('users/update',{
            data: user[0]
        })

    }

    async update(req, res){

        await UserService.update(req.body, req.params.id);
        res.redirect('/users');
    }

    async delete(req,res){

        await UserService.delete(req.params.id); 
        res.redirect('/users');
    }
}

module.exports = new UserController();