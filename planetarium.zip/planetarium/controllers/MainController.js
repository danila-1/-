const SessionService = require('../services/SessionService');
const flash = require('connect-flash');

class MainController {

    async main(req, res){
        const sessions = await SessionService.all();
        res.render('main', {data: sessions, message: req.flash('message'), selected: req.body.select});
    }

    async select(req, res){
        
        if (req.body.select === '1'){
            const sessions = await SessionService.all();
            res.render('main', {data: sessions, selected: req.body.select,  message: req.flash('message')});
        }

        else if (req.body.select === '2'){
            const sessions = await SessionService.my(req.session.auth.id);
            res.render('main', {data: sessions, selected: req.body.select, message: req.flash('message')});
        }
    }

    
    async buy(req,res){
        if(!req.session.auth.id){
            res.redirect('/');        
        }

        const check = await SessionService.check(req.session.auth.id, req.params.id);

        if(check.length > 0)
        {
            req.flash('message', 'Вы уже записаны на выбранный сеанес')
        }
        
        else{
            await SessionService.buy(req.params.id, req.session.auth.id, 3);
            req.flash('message', 'Запись прошла успешно');
  
        }
        res.redirect('/');
    }

    async unbuy(req,res){
        if(!req.session.auth.id){
            res.redirect('/');        
        }
        const check = await SessionService.check(req.session.auth.id, req.params.id);
        if(check.length > 0)
        {
            await SessionService.unbuy(req.session.auth.id, req.params.id);  
            req.flash('message', 'Запись отменена')
        }
        
        else{
                      
            req.flash('message', 'Не удалось отменить запись');
        }
        
        res.redirect('/');
    }
}

module.exports = new MainController(); 