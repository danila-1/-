const DB = require('../DB');
const crypto = require('crypto');

class UserService{
    async update(params, id){
        const{name, login, phone} = params;
        return await new Promise((resolve, reject) => {
            DB.query('UPDATE users SET name = ?, user_name = ?, phone = ? WHERE id = ?', [name, login, phone, id], (err, elements) =>{
                if(err){
                    return reject(err);
                }
                else{
                    return resolve(elements);
                }
            });
        })
    }

    async registration(params){
        const {name, phone, email, password, login}=params;
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        return await new Promise((resolve, reject) => {
            DB.query(`INSERT INTO users VALUES (null,?,?,?,2,?,?)`,
                [name, phone, email, hash, login],
                (error, elements) => {
                    if (error) {
                        return reject(error);
                    }
                    return resolve(elements);
                });
        });
    }

    async delete(id){
        return await new Promise((resolve, reject) => {
            DB.query('DELETE FROM users WHERE id = ?', [id], (err, elements) =>{
                if(err){
                    return reject(err);
                }
                else{
                    return resolve(elements);
                }
            });
        })
    }

    async all(){
        return await new Promise((resolve, reject) => {
            DB.query('SELECT * FROM users', (err, elements) =>{
                if(err){
                    return reject(err);
                }
                else{
                    return resolve(elements);
                }
            });
        })
    }

    async one(id){
        return await new Promise((resolve, reject) => {
            DB.query('SELECT * FROM users WHERE id = ?', [id], (err, elements) =>{
                if(err){
                    return reject(err);
                }
                else{
                    return resolve(elements);
                }
            });
        })
    }
}

module.exports = new UserService();