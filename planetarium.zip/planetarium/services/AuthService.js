const db = require('../DB.js');
const crypto = require('crypto');

class AuthService{

    async check(login,password){
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        console.log(hash);
        return await new Promise((resolve, reject) => {
            db.query('SELECT * FROM `users` where `user_name`=? and `password`=? limit 1', [login,hash], (error, elements) => {
                if (error) {
                    return reject(error);
                }
                return resolve(elements);
            });
        });
    }

    async checkLogin(name){
        return await new Promise((resolve, reject) => {
            db.query('SELECT * FROM `users` where `user_name`=? limit 1',[name], (error, elements) => {
                if (error) {
                    return reject(error);
                }
                return resolve(elements);
            });
        });
    }



    async registration(params){
        const {name, phone, email, password, login}=params;
        const hash = crypto.createHash('sha256').update(password).digest('hex');
        return await new Promise((resolve, reject) => {
            db.query(`INSERT INTO users VALUES (null,?,?,?,1,?,?)`,
                [name, phone, email, hash, login],
                (error, elements) => {
                    if (error) {
                        return reject(error);
                    }
                    return resolve(elements);
                });
        });
    }

}

module.exports = new AuthService();