const DB = require('../DB');


function rand(bottom, top) {
    return function() {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
    }
}

class SessionService {


    async all() {
        return await new Promise((resolve, reject) => {
            DB.query('SELECT * FROM session WHERE date > NOW()', (error, elements) => {
                if (error) {
                    return reject(error);
                }
                return resolve(elements);
            });
        });
    }

    async my(id){
        return await new Promise((resolve, reject) => {
        DB.query('SELECT session.id as id, name, time_start, time_end, date FROM tickets JOIN session ON session_id = session.id WHERE user_id = ?',[id],
            (error, elements) => {
                if(error){
                    return reject(error);
                }
                return resolve(elements);
            })
        });
    }

    async create(params){
        return await new Promise((resolve, reject) => {
            const {name, times, timee, date} = params;
            DB.query('INSERT INTO session VALUES (null, ?, ?, ?, ?)',
                [name, times, timee, date],
                (error, elements) => {
                    if(error){
                        return reject(error);
                    }
                    return resolve(elements);
                })
        })
    }

    async update(params, id){
        return await new Promise((resolve, reject) => {
            const {name, times, timee, date} = params;
            DB.query('UPDATE session SET name = ?, time_start = ?, time_end = ?, date = ? WHERE id = ?',
                [name, times, timee, date, id],
                (error, elements) => {
                    if(error){
                        return reject(error);
                    }
                    return resolve(elements);
                })
        })
    }

    async delete(id){
        return await new Promise((resolve, reject) => {
            DB.query('DELETE from session where id=?',[id], (error, elements) => {
                if (error) {
                    return reject(error);
                }
                return resolve(elements);
            });
        });
    }

    async one(id){
        console.log(id);
        return await new Promise((resolve, reject) =>{
            DB.query('SELECT * FROM session where id = ?',[id], (error, elements) =>{
                if(error){
                    return reject(error); 
                }               
                return resolve(elements);
                
            });
        });
    }

    async check(id, session){
        return await new Promise((resolve, reject) =>{
            DB.query('SELECT * FROM tickets WHERE user_id = ? AND session_id = ?',[id, session], (error, elements) =>{
                if(error){
                    return reject(error); 
                }
                return resolve(elements);
            });
        });
    }

    async buy(session, id, hall){

        return await new Promise((resolve, reject) =>{
            DB.query('INSERT INTO tickets VALUE(null, 500, ?, ?, ?)',[session,id,hall], (error, elements) =>{
                if(error){
                    return reject(error); 
                }
                return resolve(elements);
            });
        });
    }


    async unbuy(session, id){            
        return await new Promise((resolve, reject) =>{
            DB.query('DELETE FROM tickets WHERE user_id = ? AND session_id = ?',[session,id], (error, elements) =>{
                if(error){
                    return reject(error); 
                }
                return resolve(elements);
            });
        });
    }



}

module.exports = new SessionService();