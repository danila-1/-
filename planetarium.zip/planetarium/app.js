const express = require('express');
const app = express();
const flash = require('connect-flash');

const userRoutes = require('./routes/users');
const authRoutes = require('./routes/auth');
const sessionRoutes = require('./routes/session');
const mainRoutes = require('./routes/main');


const bodyParser = require("body-parser");
const path = require("path");

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
const session = require('express-session');
app.use(session({
    secret: 'supermegasecrethardpassword',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 3600000}
}));
app.use((req,res,next)=>{
    let user = {}
    if(req.session.auth){
        user = req.session.auth
    }
    res.locals.auth = user
    next()});

app.use(flash());

app.use('/public', express.static('public'));
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

app.use('/users', userRoutes)
app.use('/auth', authRoutes);
app.use('/session', sessionRoutes);
app.use('/', mainRoutes);

app.listen(8080);