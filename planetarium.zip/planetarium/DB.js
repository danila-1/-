const mysql = require('mysql2');
const connection = mysql.createConnection({
    host: 'web.edu',
    user: '20042',
    database: '20042_planetarium',
    password: 'aubnle'
})

module.exports = connection;